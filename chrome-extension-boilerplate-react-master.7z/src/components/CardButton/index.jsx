import React from 'react';
import './style.scss';
export default function CardButton(props) {
  return <div className="cardbutton">{props.text}</div>;
}
