import React from 'react';
import './style.scss';
export default function ChangeAvatar() {
  return <div className="changeavater">Some Design</div>;
}
